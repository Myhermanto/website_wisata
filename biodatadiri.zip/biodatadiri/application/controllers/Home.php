<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{

	public function index()
	{
		$this->load->view('v_index');
	}
	public function bukutamu()
	{
		$nama = $this->input->post('xnama');
		$email = $this->input->post('xemail');
		$subject = $this->input->post('xsubject');
		$pesan = $this->input->post('xmessage');

		$simpan = $this->db->query("INSERT INTO tbl_bukutamu  
								  (nama,email,subject,pesan)values('$nama','$email','$subject','$pesan')");
		redirect('home');
	}
	public function administrator()
	{
		$data['data'] = $this->db->query("select* from tbl_bukutamu")->result();
		$this->load->view('v_admin', $data);
	}
}