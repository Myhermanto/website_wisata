<html>
<title>Administrator</title>

<body>

    <center>
        <h1>Halaman Administrator
        </h1>
    </center>
    <br>
    <table border="1" align="center">
        <thead>
            <th>No </th>
            <th>Nama </th>
            <th> Email </th>
            <th>Subject</th>
            <th>Pesan</th>
        </thead>

        <tbody>
            <?php
            $no = 0;
            foreach ($data as $row):
                $no++;
            ?>
                <tr>
                    <td> <?php echo $no ?>
                    </td>
                    <td>
                        <?php echo $row->nama; ?></td>
                    <td><?php echo $row->email; ?></td>
                    <td><?php echo $row->subject; ?></td>
                    <td><?php echo $row->pesan; ?></td>


                </tr>
            <?php endforeach ?>

        </tbody>

    </table>
</body>

</html>