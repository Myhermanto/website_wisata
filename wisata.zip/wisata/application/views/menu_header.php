<!-- Navbar & Hero Start -->
<div class="container-fluid position-relative p-0">
    <nav class="navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0">
        <a href="" class="navbar-brand p-0">
            <h1 class="text-primary"><i class="fas fa-home"></i>Wisata Kalbar</h1>
            <!-- <img src="img/logo.png" alt="Logo"> -->
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="fa fa-bars"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto py-0">
                <a href="<?= base_url() ?>home" class="nav-item nav-link active">Beranda</a>
                <a href="<?= base_url() ?>home/tentangkami" class="nav-item nav-link">Tentang Kami</a>
                <a href="<?= base_url() ?>home/wisata" class="nav-item nav-link">Wisata</a>
                <a href="<?= base_url() ?>home/artikel" class="nav-item nav-link">Artikel</a>

                <a href="<?= base_url() ?>home/kontak" class="nav-item nav-link">Kontak Kami</a>
            </div>

        </div>
    </nav>

    <!-- Carousel Start -->

    <!-- Carousel End -->
</div>