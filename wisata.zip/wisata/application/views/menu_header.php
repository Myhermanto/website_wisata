<!-- Topbar Start -->
<div class="container-fluid topbar bg-light px-5 d-none d-lg-block">
    <div class="row gx-0 align-items-center">
        <div class="col-lg-8 text-center text-lg-start mb-2 mb-lg-0">
            <div class="d-flex flex-wrap">
                <a href="#" class="text-muted small me-4"><i class="fas fa-map-marker-alt text-primary me-2"></i>Find A
                    Location</a>
                <a href="tel:+01234567890" class="text-muted small me-4"><i
                        class="fas fa-phone-alt text-primary me-2"></i>+01234567890</a>
                <a href="mailto:example@gmail.com" class="text-muted small me-0"><i
                        class="fas fa-envelope text-primary me-2"></i>Example@gmail.com</a>
            </div>
        </div>
        <div class="col-lg-4 text-center text-lg-end">
            <div class="d-inline-flex align-items-center" style="height: 45px;">
                <a href="#"><small class="me-3 text-dark"><i class="fa fa-shopping-cart text-primary me-2"></i>Pesan
                        Tiket</small></a>
                <a href="#"><small class="me-3 text-dark"><i class="fa fa-list text-primary me-2"></i>Promo!</small></a>

            </div>
        </div>
    </div>
</div>
<!-- Topbar End -->

<!-- Navbar & Hero Start -->
<div class="container-fluid position-relative p-0">
    <nav class="navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0">
        <a href="" class="navbar-brand p-0">
            <h1 class="text-primary"><i class="fas fa-home"></i>Wisata Kalbar</h1>
            <!-- <img src="img/logo.png" alt="Logo"> -->
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="fa fa-bars"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto py-0">
                <a href="<?= base_url() ?>home" class="nav-item nav-link active">Beranda</a>
                <a href="<?= base_url() ?>home/tentangkami" class="nav-item nav-link">Tentang Kami</a>
                <a href="service.html" class="nav-item nav-link">Object Wisata</a>
                <a href="blog.html" class="nav-item nav-link">Budaya</a>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link" data-bs-toggle="dropdown">
                        <span class="dropdown-toggle">Artikel</span>
                    </a>
                    <div class="dropdown-menu m-0">
                        <a href="feature.html" class="dropdown-item">wisata Pulau</a>
                        <a href="team.html" class="dropdown-item">budaya </a>
                        <a href="testimonial.html" class="dropdown-item">festival</a>
                        <a href="offer.html" class="dropdown-item">kuliner</a>

                    </div>
                </div>
                <a href="contact.html" class="nav-item nav-link">Kontak Kami</a>
            </div>

        </div>
    </nav>

    <!-- Carousel Start -->

    <!-- Carousel End -->
</div>