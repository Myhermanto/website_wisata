<div class="nav-scroller bg-body shadow-sm">
    <nav class="nav" aria-label="Secondary navigation">
        <a class="nav-link active" aria-current="page" href="<?= base_url() ?>dashboard">Dashboard</a>

        <a class="nav-link" href="<?= base_url() ?>Tentangkami_admin">Tentang Kami</a>
        <a class="nav-link" href="#">Object Wisata</a>
        <a class="nav-link" href="#">Budaya</a>
        <a class="nav-link" href="<?= base_url() ?>artikel">Artikel</a>
        <a class="nav-link" href="#">Kontak Kami</a>
        <a class="nav-link" href="#">Pengguna Admin</a>
        <a class="nav-link" href="<?= base_url() ?>">Keluar</a>
    </nav>
</div>