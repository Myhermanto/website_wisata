<div class="nav-scroller bg-body shadow-sm">
    <nav class="nav" aria-label="Secondary navigation">
        <a class="nav-link active" aria-current="page" href="<?= base_url() ?>dashboard">Dashboard</a>

        <a class="nav-link" href="<?= base_url() ?>Tentangkami_admin">Tentang Kami</a>
        <a class="nav-link" href="#"> Wisata</a>
        <a class="nav-link" href="<?= base_url() ?>artikel">Artikel</a>
        <a class="nav-link" href="<?= base_url() ?>User">Pengguna Admin</a>
        <a class="nav-link" href="<?= base_url() ?>login/logout">Keluar</a>
    </nav>
</div>