<?php
defined('BASEPATH') or exit('No direct script access allowed');

class TentangKami extends CI_Controller
{

	public function index()
	{
		$this->load->view('index_tentangkami');
	}

	public function simpan()
	{
		$judul = $this->input->post('xjudul');
		$isi = $this->input->post('xisiberita');
		$tgl = $this->input->post('xtanggal');
		$gambar = $this->input->post('xfoto');
		$simpan = $this->db->query("insert into tbl_berita 
								  (judul_berita,isi_berita,tgl_berita)values('$judul','$isi','$tgl')");
		redirect('Dashboard');
	}

	public function edit() {}

	public function hapus() {}
}