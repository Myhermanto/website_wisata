<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{

	public function index()
	{
		$data['user'] = $this->db->query("select* from tbl_user")->result();
		$this->load->view('index_user', $data);
	}

	public function tambahdata()
	{
		$this->load->view('tambah_user');
	}

	public function simpan()
	{
		$nama = $this->input->post('xnama');
		$username = $this->input->post('xusername');
		$password = $this->input->post('xpassword');
		$tgl = $this->input->post('xtanggal');

		$simpan = $this->db->query("INSERT INTO tbl_user 
								  (nama,username,password,tgl_create)values('$nama','$username','$password','$tgl')");
		redirect('user');
	}
	public function hapus($id)
	{
		$hapus = $this->db->query(" DELETE FROM  tbl_user WHERE id_user='$id' ");
		redirect('user');
	}

	public function edit($id)
	{
		$data['data'] = $this->db->query(" SELECT* FROM  tbl_user WHERE id_user='$id' ")->row();
		$this->load->view('edit_user', $data);
	}

	public function update($id)
	{
		$nama = $this->input->post('xnama');
		$username = $this->input->post('xusername');
		$password = $this->input->post('xpassword');
		$tgl = $this->input->post('xtanggal');
		$simpan = $this->db->query("UPDATE tbl_user  set nama='$nama',username='$username',password='$password', tgl_create='$tgl'
								  WHERE id_user='$id'");
		redirect('user');
	}
}
