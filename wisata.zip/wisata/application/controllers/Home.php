<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{

	public function index()
	{
		$data['artikel'] = $this->db->query("select* from tbl_berita")->result();
		$this->load->view('index', $data);
	}

	public function tentangkami()
	{
		$data['data'] = $this->db->query("select* from tbl_tentangkami limit 1")->row();
		$this->load->view('index_tentangkami_home', $data);
	}
}
