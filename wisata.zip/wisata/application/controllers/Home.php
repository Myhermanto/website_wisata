<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{

	public function index()
	{
		$data['artikel'] = $this->db->query("select* from tbl_berita")->result();
		$this->load->view('index', $data);
	}

	public function detail_artikel($id)
	{
		$data['artikel'] = $this->db->query("select * from tbl_berita where id_berita='$id' ")->row();
		$this->load->view('v_detail_artikel', $data);
	}

	public function tentangkami()
	{
		$data['data'] = $this->db->query("select* from tbl_tentangkami limit 1")->row();
		$this->load->view('index_tentangkami_home', $data);
	}

	public function wisata()
	{
		$data['artikel'] = $this->db->query("select* from tbl_berita")->result();
		$this->load->view('wisata_home', $data);
	}

	public function artikel()
	{
		$data['artikel'] = $this->db->query("select* from tbl_berita")->result();
		$this->load->view('artikel_home', $data);
	}

	public function kontak()
	{
		$this->load->view('kontak_home');
	}
}
