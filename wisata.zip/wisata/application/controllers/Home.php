<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{

	public function index()
	{

		$this->load->view('index');
	}

	public function tentangkami()
	{
		$data['data'] = $this->db->query("select* from tbl_tentangkami limit 1")->row();
		$this->load->view('index_tentangkami_home', $data);
	}
}