<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Artikel extends CI_Controller
{

	public function index()
	{
		$data['artikel'] = $this->db->query("select* from tbl_berita")->result();
		$this->load->view('index_artikel', $data);
	}

	public function tambahdata()
	{
		$this->load->view('tambah_artikel');
	}
	public function simpan()
	{
		$judul = $this->input->post('xjudul');
		$isi = $this->input->post('xisiberita');
		$tgl = $this->input->post('xtanggal');
		$gambar = $this->input->post('xfoto');
		$simpan = $this->db->query("insert into tbl_berita 
								  (judul_berita,isi_berita,tgl_berita)values('$judul','$isi','$tgl')");
		redirect('Artikel');
	}

	public function edit() {}

	public function hapus() {}
}
