<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Tentangkami_admin extends CI_Controller
{

	public function index()
	{
		$data['artikel'] = $this->db->query("select* from tbl_tentangkami")->result();
		$this->load->view('index_tentangkami', $data);
	}

	public function tambahdata()
	{
		$this->load->view('tambah_tentangkami');
	}

	public function simpan()
	{
		$isi = $this->input->post('xisiketerangan');
		$tgl = $this->input->post('xtanggal');
		$simpan = $this->db->query("INSERT INTO tbl_tentangkami 
								  (isi_keterangan,tgl_create)values('$isi','$tgl')");
		redirect('Tentangkami_admin');
	}
	public function hapus($id)
	{
		$hapus = $this->db->query(" DELETE FROM  tbl_tentangkami WHERE id_tk='$id' ");
		redirect('Tentangkami_admin');
	}

	public function edit($id)
	{
		$data['data'] = $this->db->query(" SELECT* FROM  tbl_tentangkami WHERE id_tk='$id' ")->row();
		$this->load->view('edit_tentangkami', $data);
	}

	public function update($id)
	{
		$isi = $this->input->post('xisiketerangan');
		$tgl = $this->input->post('xtanggal');
		$simpan = $this->db->query("UPDATE tbl_tentangkami  set isi_keterangan='$isi', tgl_create='$tgl'
								  WHERE id_tk='$id'");
		redirect('Tentangkami_admin');
	}
}
