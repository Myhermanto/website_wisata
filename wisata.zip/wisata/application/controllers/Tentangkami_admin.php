<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Tentangkami_admin extends CI_Controller
{

	public function index()
	{
		$data['artikel'] = $this->db->query("select* from tbl_tentangkami")->result();
		$this->load->view('index_tentangkami', $data);
	}

	public function tambahdata()
	{
		$this->load->view('tambah_tentangkami');
	}

	public function simpan()
	{
		$isi = $this->input->post('xisiketerangan');
		$tgl = $this->input->post('xtanggal');
		$simpan = $this->db->query("insert into tbl_tentangkami 
								  (isi_keterangan,tgl_create)values('$isi','$tgl')");
		redirect('Tentangkami_admin');
	}
}